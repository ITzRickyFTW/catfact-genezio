package com.example.catfact

data class CatFact(val fact:String,val length:UShort)

